const fs = require('fs').promises
const path = require('path')
const {run} = require('../lib/run.js')

// 3. replaceInsertPointWithBlock
// 5. Caching of block content

const pagesPath = 'pages'
const blocksPath = 'blocks'

run(main)

async function main() {
    console.log('Composing pages...')
    const pageFilenames = await fs.readdir(pagesPath)
    for (const pageFilename of pageFilenames) {
        console.log(`Composing page "${pageFilename}"...`)
        composePage(pageFilename)
    }
    console.log('Done composing pages.')
}

async function composePage(pageFilename) {
    const pagePath = path.join(pagesPath, pageFilename)
    const content = await fs.readFile(pagePath, {encoding: 'utf8'})
    const blockInsertPointRegExp = /<!-- BLOCK: (.+?) -->/g
    let composedContent = content
    let result
    while ((result = blockInsertPointRegExp.exec(composedContent)) !== null) {
        const blockFilename = result[1]
        const blockPath = path.join(blocksPath, blockFilename)
        const blockContent = await fs.readFile(blockPath)
        // This supports using insert points in blocks
        composedContent = (
            composedContent.substring(0, result.index) +
            blockContent +
            composedContent.substring(result.index + result[0].length)
        )
    }
    await fs.writeFile(pageFilename, composedContent, {encoding: 'utf8'})
}
