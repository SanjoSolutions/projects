package com.company.client.tpms.ui.activity;


import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * To handle Login action of the user
 * @version History:
 *      @author Uma
 *      @version V1.0 {@date} 16/03/2018
 */
public class LoginActivity
		extends AppCompatActivity
		implements OnClickListener {

	// Used in debugging
	private static final String TAG = LoginActivity.class.getSimpleName();

	// Editable text views
	private EditText etUsername, etPassword;

	private Spinner selecetedUserType;

	private TextView joinNow, serverUrlWarning, changeServerButton;

	private TextView tvUsername, tvPassword;

	private TextView login, forgot_password, doNotHaveyet, join_now;
	// Buttons
	private Button btnLogin;

	private TextView language_View;

	private Button transPopId;

	private TextView btnForgotPassword;

	public Dialog dialog;

	// Context of this file
	private Context context;

	private static String userType;

	// Realm instance
	//private Realm realm;

	// Snack bar view
	private Snackbar networkErrorSnackbar;
	private static ProgressDialog loadingProgress;
	private ServerTypeListViewDTO selectedChangedServerTypeDetails;

	//	private TextView txt_hello;
	private Locale myLocale;
	private ImageView img;
	Context mContext;
	private String langchange;

	SharedPreferences sharedPreferences;
	SharedPreferences.Editor editor;

	/**
	 * Called when the activity is starting.
	 *
	 * @param savedInstanceState - If the activity is being re-initialized after
	 *                           previously being shut down then this Bundle contains the data it most recently
	 *                           supplied in onSaveInstanceState(Bundle). Note: Otherwise it is null.
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} - 15/03/2018
	 * @author Pushpalatha
	 * @version V3.10.0 {@date} 19/06/2019 - Vehicle layout - commented out - use it before
	 * initializing dummy data
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Log.d(TAG, "::onCreate() RC:[ " + TPMSApp.getRealmCount() + " ]");

		// Set UI view for this screen
		setContentView(R.layout.layout_login);

		// Set context for this activity
		context = this;

		// Set tool bar and footer image
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		AppCompatImageView logo = toolbar.findViewById(R.id.logo_toolbar);

		if (AppMarket.GLOBAL == AppMarket.getAppMarket(BuildConfig.Market)) {

			logo.setImageResource(R.drawable.ic_client_logo);
			//toolbar.setLogo(R.drawable.ic_client_logo);
			findViewById(R.id.footerImageView).getLayoutParams().width = RelativeLayout.LayoutParams.MATCH_PARENT;
			findViewById(R.id.footerImageView).setBackground(
					context.getDrawable(R.drawable.client_tyre));

		} else if (AppMarket.CENTAURO_HUNGARY == AppMarket.getAppMarket(BuildConfig.Market)) {

			logo.setImageResource(R.drawable.ic_centauro_hungary_vredestein_logo);
			//toolbar.setLogo(R.drawable.ic_centauro_hungary_vredestein_logo);
			findViewById(R.id.footerImageView).setBackgroundResource(R.drawable.ic_centauro_image);

		}

		setSupportActionBar(toolbar);
/*
		try {

			// Get realm instance
			this.realm = Realm.getDefaultInstance();
		} catch (RealmMigrationNeededException e) {

			// Delete the realm configuration
			RealmConfiguration config2 = new RealmConfiguration.Builder()
					.deleteRealmIfMigrationNeeded()
					.build();

			// Set the configuration
			Realm.setDefaultConfiguration(config2);

			// Get realm instance
			this.realm = Realm.getDefaultInstance();


		}
*/

		// Find UI views by their Id's
		findViews();

		// Commented on 05-06-2018
		// - Due to the implementation of admin user registration @author Uma
		// Initialize necessary records in database
		//UserDao.initializeNecessaryRecords();

		// Set user types
		setUserTypeSpinner();

		// TODO: For testing on 30-05-18
		// set up rest client
		//TPMSApp.setUpRestClient();

		// Register in event bus to receive events
		EventBusManager.register(this);

		// Start Sync service
		//Log.d(TAG, "::OnCreate > start sync service..");
		//SyncService.start(context);

		// Start TPMS RX service
		startBackgroundService();

		// clear all vehicle layout records  - Commented @date 26/05/2019 @author Pushpalatha

		//VehicleLayoutDao.removeAll();

		this.selectedChangedServerTypeDetails = null;

		Log.d(TAG, "::onCreate() end RC:[ " + TPMSApp.getRealmCount() + " ]");
		loadLocale();
	}// end of protected void onCreate(Bundle savedInstanceState) {


	/*
    To start the background service
   */

	public void startBackgroundService() {

		// if the service is not running, start it
		if (!isMyServiceRunning(TpmsRxService.class)) {
			Log.e(TAG, "::startBackgroundService>> Starting the TpmsRxService....");
			// start the service
			Intent serviceIntent = new Intent(context, TpmsRxService.class);
			//context.startService(serviceIntent); @version 3.12.4 - app crashed issue fix android 9- after installed cant start service
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				context.startForegroundService(serviceIntent);
			} else {
				context.startService(serviceIntent);
			}
		}

		if (!isMyServiceRunning(SyncService.class)) {
			Log.e(TAG, "::startBackgroundService>> Starting the SyncService....");
			// start the service
			/*Intent syncServiceIntent = new Intent(context, SyncService.class);
			context.startService(syncServiceIntent);*/
			SyncService.start(context);
		}

	}


	/*
    To check whether the service is currently running or not
     */
	private boolean isMyServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {

				Log.e(TAG, ":: Background service is already running");
				return true;
			}
		}

		Log.e(TAG, ":: Background service is not running");
		return false;
	}


	/**
	 * To set user type in a spinner
	 *
	 * @version History:
	 * @author Pushpalatha
	 * @version V1.0 {@date} 19/03/2018
	 */
	private void setUserTypeSpinner() {

		// Initialize user type list
		ArrayList<String> userTypeList = new ArrayList<>();
		userTypeList.add("ADMIN");
		userTypeList.add("DRIVER");


		// Set return reasons into returnReasonSpinner
		final ArrayAdapter<String> userTypeAdapter = new ArrayAdapter<String>(context,
				android.R.layout.simple_spinner_item,
				userTypeList);
		userTypeAdapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
		this.selecetedUserType.setAdapter(userTypeAdapter);

		// Set user type selected listener
		this.selecetedUserType.setOnItemSelectedListener(
				new AdapterView.OnItemSelectedListener() {
					@Override
					public void onItemSelected(
							AdapterView<?> adapterView, View view, int i, long l) {

						// Set user type
						userType = adapterView.getSelectedItem().toString();
					}

					@Override
					public void onNothingSelected(AdapterView<?> adapterView) {

					}
				});// end of this.selecetedUserType.setOnItemSelectedListener(

	}

	/**
	 * To load the menu content
	 *
	 * @param menu - menus to be loaded
	 * @return status
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} - 15/03/2018
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_login, menu);
		return true;
	}


	/**
	 * To clear records of Transaction tables
	 * and also to update the table sync summary table
	 *
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 16/03/2018
	 */
/*
	private static void clearDatabase() {

		// TODO: ADD LATER cleaning transaction  tables

		Log.d(TAG, "::clearDatabase > TyreHealthDao removeAll Started");
		TyreHealthDao.removeAll();

		Log.d(TAG, "::clearDatabase > TyreSettingsDao removeAll Started");
		TyreSettingsDao.removeAll();

		Log.d(TAG, "::clearDatabase > VehicleDao removeAll Started");
		VehicleDao.removeAll();

		Log.d(TAG, "::clearDatabase > VehicleCategoryDao removeAll Started");
		VehicleCategoryDao.removeAll();

		Log.d(TAG, "::clearDatabase > UserDao removeAll Started");
		UserDao.removeAll();

		// TODO: ADD LATER reset of transactions

	}
*/
	@Override
	protected void onPause() {
		super.onPause();
		Log.d(TAG, "::onPause() RC:[ " + TPMSApp.getRealmCount() + " ]");

	}

	/**
	 * To handle OnResume Actions
	 *
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 16/03/2018
	 * @author Damarnadh
	 * @version V3.10.0 {@date} 05/06/2018
	 */
	@Override
	protected void onResume() {

		super.onResume();

		Log.d(TAG, "::onResume() RC:[ " + TPMSApp.getRealmCount() + " ]");

		Realm realm = Realm.getDefaultInstance();
		// checking for user is present
		if (LoginUserDao.getCurrentUser() != null) {

			// checking for user logout Status
			if (LoginUserDao.getCurrentUser().isLogoutStatus() == false) {

				switchToNextScreen();
			}//end of -if(LoginUserDao.getCurrentUser()!=null){
		}//end of -if(LoginUserDao.getCurrentUser().isLogoutStatus() == false){

		realm.close();

		//Set connected server details to User
		setServerDetailsInUI();

	}// end of protected void onResume() {

	/**
	 * To find UI views by their Unique Id's
	 *
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 16/03/2018
	 */
	private void findViews() {
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		editor = sharedPreferences.edit();
		// Buttons
		btnLogin = (Button) findViewById(R.id.btnLogin);
		//	btnLogin = (Button) findViewById(R.id.btnLogin);
		btnForgotPassword = (TextView) findViewById(R.id.forgot_password);
		//setContentView(R.layout.layout_login);
		this.tvUsername = (TextView) findViewById(R.id.tvUsername);
		this.tvPassword = (TextView) findViewById(R.id.tvPassword);
		login = (TextView) findViewById(R.id.login);
		//doNotHaveyet = (TextView) findViewById(R.id.doNotHaveyet);

		// Editable text views
		etUsername = (EditText) findViewById(R.id.etUsername);
		etPassword = (EditText) findViewById(R.id.etPassword);
		// spinner
		selecetedUserType = (Spinner) findViewById(R.id.userType);
		joinNow = (TextView) findViewById(R.id.join_now);
		changeServerButton = (TextView) findViewById(R.id.changeServerButton);
		serverUrlWarning = (TextView) findViewById(R.id.serverUrlWarning);
		transPopId = (Button) findViewById(R.id.btn_Trans);
		language_View = (TextView) findViewById(R.id.lang_view);

		// On click listener for the buttons
		btnLogin.setOnClickListener(this);
		btnForgotPassword.setOnClickListener(this);
		joinNow.setOnClickListener(this);
		changeServerButton.setOnClickListener(this);
		transPopId.setOnClickListener(this);

	}// end of private void findViews() {


	/**
	 * To perform actions for clicking buttons
	 *
	 * @param v - Tapped view
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 16/03/2018
	 */
	@RequiresApi(api = Build.VERSION_CODES.M)
	@Override
	public void onClick(View v) {

		// Get id of the view
		int clickedViewId = v.getId();
		switch (clickedViewId) {

			// Check if clicked view is login button
			case R.id.changeServerButton:
				// check entered details & fire login request
				this.getPassword();
				break;

			// Check if clicked view is login button
			case R.id.btnLogin:
				// check entered details & fire login request
				this.loginCheck();
				break;

			// Check if clicked view is forgot password button
			case R.id.forgot_password:
				// get email and send the link
				this.getEmailAndSendResetLink();

				break;
			case R.id.join_now:
				// navigate to registration screen
				this.switchToRegistrationScreen();
				break;

				//Edited by Nikhil
			case R.id.btn_Trans:
				selectLanguage();
				break;

		}// end of 	public void onClick(View v) {


	}


	/**
	 * To get email and send the reset link
	 *
	 * @version history:
	 * @author Pushpalatha
	 * @version CH-V1.0 {@date} 18/10/2019
	 */
	private void getEmailAndSendResetLink() {

		// If no net connection, alert the user
		if (!NetworkUtils.checkNetworkConnection(context)) {
			Toast.makeText(context, "No net connection", Toast.LENGTH_LONG).show();
			return;
		}


		// Declare the builder here
		final AlertDialog.Builder emailDialog = new AlertDialog.Builder(this);

		// Set message
		emailDialog.setMessage(getString(R.string.regeml));

		// Set an EditText view to get user input
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		params.setMargins(20, 30, 30, 0);
		final EditText input = new EditText(this);
		input.setHint("Enter email");
		layout.addView(input, params);
		emailDialog.setView(layout);

		// set "Cancel" button to close the dialog
		emailDialog.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				dialogInterface.dismiss();
			}
		});


		// Set "Send reset link" button to send the link
		emailDialog.setPositiveButton(getString(R.string.sndlink), null);

		final AlertDialog getEmailBuilder = emailDialog.create();

		// show the alert dialog
		getEmailBuilder.show();


		getEmailBuilder.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(
				new OnClickListener() {
					@Override
					public void onClick(View view) {
						// email entered by the user
						String email = input.getText().toString();


						// check for validation
						if (!Constants.isValidEmailEmpty(email)) {

							AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
							builder.setTitle("Info");
							builder.setMessage("please Enter Your e-mail id");
							builder.setPositiveButton("OK", null);
							AlertDialog dialog = builder.show();
							TextView messageText = dialog.findViewById(android.R.id.message);
							messageText.setGravity(Gravity.CENTER);
							return;
						}
						if (!Constants.isValidEmailMatches(email)) {

							AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
							builder.setTitle("Info");
							builder.setMessage("Please Enter valid e-mail id");
							builder.setPositiveButton("OK", null);
							AlertDialog dialog = builder.show();
							TextView messageText = dialog.findViewById(android.R.id.message);
							messageText.setGravity(Gravity.CENTER);
							return;
						}

						try {
							// Show "Loading" message , which cannot be cancelable by the user
							loadingProgress = new ProgressDialog(context);
							loadingProgress.setMessage("Sending... Please wait");
							loadingProgress.setCancelable(false);
							loadingProgress.show();

							// send email id to the server
							ForgotPasswordReqEvent.send(email.trim());
						} catch (Exception e) {

							// Invalidate the progress dialog
							loadingProgress = null;
							e.printStackTrace();
						}

						// Close the alert dialog
						getEmailBuilder.dismiss();
					}
				}
		);


	}


	/******************************************************************************************
	 * To receive an event
	 * @param event ForgotPasswordRespEvent
	 * @version History:
	 *      @author Pushpalatha
	 *      @version CH-V1.0 {@date} 18/10/2019
	 ******************************************************************************************/
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onEvent(ForgotPasswordRespEvent event) {

		Log.d(TAG, "::onEvent > CALLED & Receiving event: ForgotPasswordRespEvent");

		// Dismiss the progress dialog
		if (loadingProgress != null && loadingProgress.isShowing()) {
			loadingProgress.dismiss();
			loadingProgress = null;
		}

		// Check status of server response
		// If status is true, handle different login status
		// Otherwise show error message
		if (!event.isStatus()) {

			// Show error message in the alert dialog
			MessageAlertDialog.showErrorAlert(
					event.getMessage(),        // message
					this.context);                   // context

		} else {

			// notify the user
			MessageAlertDialog.showAlertDialog("",
					event.getMessage(),
					this.context);

		}// end of else

		Log.d(TAG, "::onEvent > ForgotPasswordRespEvent method ENDED");

	}// end of   public void onEvent(ForgotPasswordRespEvent event) {


	/**
	 * To navigate to registration screen
	 *
	 * @version History:
	 * @author Uma
	 * @version V2.8.0 {@date} 15/05/2019
	 */
	private void switchToRegistrationScreen() {

		// If internet connection is not there
		if (!NetworkUtils.checkNetworkConnection(context)) {

			// show error alert & return
			MessageAlertDialog.showErrorAlert(getString(R.string.internet_conn), context);
			return;
		}

		// launch register activity
		Intent registerIntent = new Intent(context, RegisterActivity.class);
		startActivity(registerIntent);

	}


	/**
	 * To handle "Back" button of Android mobile pressed
	 *
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 15/03/2018
	 * @author Pushpalatha - close background service when app is closed
	 * @version V1.1.0.5 {@date} -  09/01/2020
	 */
	@Override
	public void onBackPressed() {

		// Stop the services
		if (isMyServiceRunning(SyncService.class)) {
			SyncService.stop(context);
		}


		// stop tpms service
		context.stopService(new Intent(context, TpmsRxService.class));

		// close all the activities
		finishAffinity();

		// remove the task associated with this activity if any
		finishAndRemoveTask();

		// Close this activity
		LoginActivity.this.finish();
	}


	/**
	 * To handle the Destroy action of this activity
	 *
	 * @version History:
	 * @author Uma
	 * @version V1.0 {@date} 15/03/2018
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();

		// Close the realm instance
		//this.realm.close();

		// Unregister from event bus
		EventBusManager.unregister(this);

		Log.d(TAG, "::onDestroy() RC:[ " + TPMSApp.getRealmCount() + " ]");

	}// end of protected void onDestroy(){

	/**
	 * login validation for input & net connection
	 *
	 * @version history
	 * @author Uma
	 * @version 3.8.0 - 14/05/2019
	 */
	@RequiresApi(api = Build.VERSION_CODES.M)
	private void loginCheck() {

		Log.d(TAG, "loginCheck called");

//		if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
//
//			MessageAlertDialog.showErrorAlert(getString(R.string.bluetooth_msg),
//					context);
//			Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
//			return;
//
//		}
		// Check entered details and network connection
		//  If any issue found, notify the user
		if ("".equals(etUsername.getText().toString())) {

			MessageAlertDialog.showErrorAlert(getString(R.string.id_log), context);
			return;
		}

		if ("".equals(etPassword.getText().toString())) {

			MessageAlertDialog.showErrorAlert(getString(R.string.password_log), context);
			return;
		}


		// Get user name and enteredPassword
		String enteredUserId = etUsername.getText().toString().trim();
		String enteredPassword = etPassword.getText().toString().trim();

		Realm realm = Realm.getDefaultInstance();

		// get user record count from DB
		LoginUser previousUser = LoginUserDao.getCurrentUser();

		// If internet connection is not there
		if (!NetworkUtils.checkNetworkConnection(context)) {

			// if login user is null
			if (previousUser == null) {

				// show error alert & return
				MessageAlertDialog.showErrorAlert(getString(R.string.internet_conn), context);


				realm.close();

				return;
			}

			//check entered enteredUserId & Password with locally saved previous user details
			// TODO:
			if (previousUser != null && !enteredUserId.contentEquals(previousUser.getUserId())) {

				Log.d(TAG, "Offline: user changed");

				// show error alert & return
				MessageAlertDialog.showErrorAlert(
						"You are currently offline and Credentials mismatched with previous user. " + "\n" +
								"Please try anyone of following: " +
								"\n * Enable mobile data / wifi\n * Login using previously used credentials",
						context);

				realm.close();

				return;
			}

			// Check entered credentials and create record for
			StatusMessageHolder loginStatusMessageHolder = LoginUserDao.loginCheck(
					enteredUserId,
					enteredPassword);

			if (!loginStatusMessageHolder.isStatus()) {
				// Show error message
				MessageAlertDialog.showErrorAlert(loginStatusMessageHolder.getMessage(), context);

				// TODO: Close instance 26/07/2019

				realm.close();

				return;

			}

			// Start TableSyncSummary Activity
			Intent tableSyncSummary = new Intent(this.context, TableSyncSummaryActivity.class);
			tableSyncSummary.putExtra("activity", LoginActivity.class.getSimpleName());
			startActivity(tableSyncSummary);

		} else {

			try {
				// Get service of Input manager
				InputMethodManager inputManager = (InputMethodManager) getSystemService(
						Context.INPUT_METHOD_SERVICE);

				// Hide the keyboard
				inputManager.hideSoftInputFromWindow(
						etUsername.getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
			} catch (Exception e) {
				e.printStackTrace();
			}

			try {

				// Show "Loading" message , which cannot be cancelable by the user
				loadingProgress = new ProgressDialog(context);

				loadingProgress.setMessage("Trying to Login... Please wait");

				anotherObject.setText("Login Activity");
				//anotherObject.setText(R.string.lgn_act);

				loadingProgress.setCancelable(false);
				loadingProgress.show();

				//Get selected language from shared preferences
				String selectedLanguage = sharedPreferences.getString(SAVED_LOCALE,
						Language.getLanguage(Language.English.getValue())); // default - english

				// send login request to the server
				LoginReqEvent.send(new LoginRequestCommDto(enteredUserId,
						enteredPassword,
						Language.getLanguage(selectedLanguage).getValue()));

			} catch (Exception e) {

				// Invalidate the progress dialog
				loadingProgress = null;
				e.printStackTrace();
			}


		}// end of else {

		//TODO: close realm instance 26/07/2019
		realm.close();

	}// end of public void loginCheck() {

	/******************************************************************************************
	 * To receive an event
	 * * @param event LoginRespEvent
	 * @version History:
	 *      @author Uma
	 *      @version V3.8.0 {@date} 14/05/2019
	 *      @author Pushpalatha
	 *      @version V3.14.0 {@date} 30/10/2019 - account activation popup added(commented)
	 ******************************************************************************************/
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onEvent(LoginRespEvent event) {

		Log.d(TAG, "::onEvent > CALLED & Receiving event: LoginResponseEvent");

		// Get response collection message
		LoginCollectionRespCommDto myLoginResponseCollection = event.getLoginRespCommDto();

		// Dismiss the progress dialog
		if (loadingProgress != null && loadingProgress.isShowing()) {
			loadingProgress.dismiss();
			loadingProgress = null;
		}

		// Check status of server response
		// If status is true, handle different login status
		// Otherwise show error message
		if (!myLoginResponseCollection.isStatus()) {


			// TODO: add it later - check for error code and show the activation link popup
//        	if(myLoginResponseCollection.getErrorCode() == RealmConstants.ONE){
//        		sendActivationLink();
//        		return;
//			}

			// Show Login error message in the alert dialog
			MessageAlertDialog.showErrorAlert(
					myLoginResponseCollection.getMessage().get(0).toString(),        // message
					this.context);                                            // context

		} else {

			// Get response data
			UserCommDto myLoginRespCommDto =
					myLoginResponseCollection.getLoginRespCommDto();

			this.switchToNextScreen(myLoginRespCommDto);

		}// end of else

		Log.d(TAG, "::onEvent > LoginResponseEvent method ENDED");

	}// end of   public void onEvent(LoginRespEvent event) {


	/**
	 * To navigate to sync summary or select customer screen
	 * and also to update the table sync summary table
	 *
	 * @version History:
	 * @author Uma
	 * @version V3.8.0 {@date} 14/05/2019
	 */
	private void switchToNextScreen(UserCommDto inLoginRespCommDto) {

		Log.d(TAG, "switchToNextScreen called");

		Realm realm = Realm.getDefaultInstance();

		// Get previously logged user details in Android
		LoginUser previousUser = LoginUserDao.getCurrentUser();

		// Or if customer id is differing for the previous and current user
		if (previousUser != null
				&& (previousUser.getUser().getServerInternalId()
				!= inLoginRespCommDto.getServerInternalId())) {

			Log.d(TAG, "switchToNextScreen: user changed");

			clearDatabase();

			LoginUserDao.removeAll();

		}

		// User Record List
		List<UserCommDto> myUserRecord = new ArrayList<>();

		myUserRecord.add(inLoginRespCommDto);

		// Update retrieved user detail in local database
		UserDao.updateDBSTA(myUserRecord);

		realm.beginTransaction();
		List<User> myUserList = UserDao.getAll(realm);
		realm.commitTransaction();

		// Write login user details into LoginUser table
		LoginUserDao.createOrUpdateRecord(inLoginRespCommDto.getUserId(), myUserList.get(0));

		//   realm.close(); TODO: removed from this place 26/07/2019

		LoginUser currentUser = LoginUserDao.getCurrentUser();

		if (currentUser != null &&
				currentUser.getUserType().
						contentEquals(UserType.getUserType(UserType.EOL_TESTER))) {

			// Start test tpms device activity
			Intent testTpmsIntent = new Intent(this.context, TestTPMSActivity.class);
			startActivity(testTpmsIntent);

		} else {

			// Start Table Sync summary activity
			Intent tableSyncSummary = new Intent(this.context, TableSyncSummaryActivity.class);
			tableSyncSummary.putExtra("activity", LoginActivity.class.getSimpleName());
			startActivity(tableSyncSummary);
		}

		realm.close(); //TODO: added from 688 line - 26/07/2019

	}// end of switchToNextScreen(

	/**
	 * To navigate to next screen
	 *
	 * @version History:
	 * @author Damarnadh
	 * @version V3.9.1 {@date} o5/06/2019
	 */

	private void switchToNextScreen() {
		LoginUser currentUser = LoginUserDao.getCurrentUser();

		if (currentUser != null &&
				currentUser.getUserType().
						contentEquals(UserType.getUserType(UserType.EOL_TESTER))) {

			// Start test tpms device activity
			Intent testTpmsIntent = new Intent(this.context, TestTPMSActivity.class);
			startActivity(testTpmsIntent);

		} else {

			// Start Table Sync summary activity
			Intent tableSyncSummary = new Intent(this.context, TableSyncSummaryActivity.class);
			tableSyncSummary.putExtra("activity", LoginActivity.class.getSimpleName());
			startActivity(tableSyncSummary);
		}

	}


	/* ==================================================
					Change Server URL
	====================================================*/

	/**
	 * To check password entered by the user
	 *
	 * @version history:
	 * @author Pushpalatha
	 * @version V3.14.0 {@date} 24/09/2019
	 */
	private void getPassword() {

		// Declare the builder here
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);

		// Set message
		builder.setMessage(getString(R.string.entrpass));

		// Set an EditText view to get user input
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		params.setMargins(20, 0, 30, 0);
		final EditText input = new EditText(this);
		layout.addView(input, params);
		builder.setView(layout);

		// Set "Go to settings" button to show configuration
		builder.setPositiveButton(getString(R.string.chngservr),  //??? rename as "change server"
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
										int whichButton) {

						// Password entered by user
						String serverConfigPass = input.getText().toString();

						// Check entered password, if matches
						// Then show server configuration
						//if (serverConfigPass.equalsIgnoreCase("{ori@SVR-19}")) {
						if (serverConfigPass.equalsIgnoreCase("123")) {

							// Show popup window
							chooseServer();

						} else {
							// Show error message to the user
							MessageAlertDialog.showErrorAlert(getString(R.string.passdoesnotmatch),
									LoginActivity.this);
						}
					}
				});

		// show the alert dialog
		builder.show();

	}


	/**
	 * To choose the
	 */
	private void chooseServer() {
		try (Realm realm = Realm.getDefaultInstance()) {

			//Get login user record
			LoginServer loginServer = LoginServerDao.getCurrentServer();

			// Initialize object for List<CharSequence> type to be sent to the alert box
			final List<ServerTypeListViewDTO> serverTypeList = new ArrayList<>();

			// server type list
			final List<ServerType> serverList = new ArrayList<ServerType>(Arrays.asList(ServerType.values()));
			// Get and add all product Id in the products list to show in the alert box
			for (int i = 0; i < serverList.size(); i++) {

				//??? add comments
				boolean isSelected = (loginServer.getServerType() == ServerType.getServerType(
						serverList.get(i)));

				serverTypeList.add(new ServerTypeListViewDTO(
						serverList.get(i),
						isSelected));

			}

			// Create dialog box to add products to the inventory //??? change comment
			final AlertDialog.Builder addProductDialogBox = new AlertDialog.Builder(context);
			// set title for the add dialog box
			addProductDialogBox.setTitle("Choose Server..");
			View viewDialog = LayoutInflater.from(context)
					.inflate(R.layout.server_type_list_layout, null, false);
			addProductDialogBox.setView(viewDialog);

			// alert box should not be canceled Except "Cancel" button
			addProductDialogBox.setCancelable(false);

			// set Pick button to choose the product and to add into the Inventory details
			addProductDialogBox.setPositiveButton(
					"Update", null);// end of addProductDialogBox.setPositiveButton(

			// Set Cancel button to close add product dialog box
			addProductDialogBox.setNegativeButton(
					"Cancel",
					new DialogInterface.OnClickListener() {

						// On click event for cancel button
						@Override
						public void onClick(DialogInterface dialogInterface, int i) {

							// close the add product dialog box
							dialogInterface.dismiss();
						}
					}// end of  DialogInterface.OnClickListener()
			);// end of  addProductDialogBox.setNegativeButton

			final AlertDialog alertDialog = addProductDialogBox.create(); //??? rename dialog name
			final RecyclerView serverListView = (RecyclerView) viewDialog.findViewById(R.id.serverTypeListView);

			alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override
				public void onShow(DialogInterface dialog) {

					ServerTypeListAdapter adapter = new ServerTypeListAdapter(serverTypeList);

					// Create Linear layout manager and set offset for it
					LinearLayoutManager llm = new LinearLayoutManager(context);
					llm.offsetChildrenVertical(5);
					serverListView.setLayoutManager(llm);
					serverListView.setHasFixedSize(true);

					// set data for recycler view
					serverListView.setAdapter(adapter);
					serverListView.addOnItemTouchListener(//??? check- is this listener needed
							new RecycleTouchListener(
									context,
									serverListView,
									new RecycleTouchListener.ClickListener() {

										@Override
										public void onClick(View view, int position) {

										}

										@Override
										public void onLongClick(View view, int position) {

										}
									}
							));
				}
			});

			// Show build addProductDialogBox alert
			alertDialog.show();

			alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(

					new View.OnClickListener() {
						@Override
						public void onClick(View v) {


							for (ServerTypeListViewDTO serverType : serverTypeList) {

								if (serverType.isSelected()) {

									// check if selected server is different, then clear the database
									int alreadySelectedServerType = LoginServerDao.getCurrentServerType();

									// check if server type is changed then clear the database
									if (alreadySelectedServerType != ServerType.getServerType(serverType.getServerType())) {

										// Sync the data first
										SyncService.request(SyncType.TYRE_HEALTH_DELETE_SYNC_ATS,
												Caller.COMPLETE_SYNC_ATS_CHANGE_SVR);

										// set selected type
										selectedChangedServerTypeDetails = serverType;
									}


									break;
								}
							}

							// Close the alert dialog
							alertDialog.dismiss();

						}// end of onClick(DialogInterface dialogInterface, int i)

					}// end of  DialogInterface.OnClickListener()
			);

		} catch (Exception e) {
			// Show error message
			MessageAlertDialog.showAlertDialog("View Parsing error",
					e.getMessage(), context);
			e.printStackTrace();
			Log.e(TAG, e.getMessage());
		}
	}

	/******************************************************************
	 *  To Set details of the server version
	 *  @version History:
	 *      @author Pushpalatha
	 *       @version 3.14.0 {@date} 24/09/2019
	 *******************************************************************/
	public void setServerDetailsInUI() {

		try (Realm realm = Realm.getDefaultInstance()) {

			// Get server type
			int serverType = LoginServerDao.getCurrentServerType();

			// hide button and view of server url change
			serverUrlWarning.setVisibility(View.GONE);
			changeServerButton.setVisibility(View.GONE);

			if (serverType != ServerType.getServerType(ServerType.PRODUCTION)) {


				serverUrlWarning.setText("Connected to " +
						ServerType.getServerTypeString(serverType) +
						" Server");

				//Show it
				serverUrlWarning.setVisibility(View.VISIBLE);
				changeServerButton.setVisibility(View.VISIBLE);

				ObjectAnimator colorAnim = ObjectAnimator.ofInt(serverUrlWarning, "textColor",
						Color.RED, Color.TRANSPARENT);

				colorAnim.setDuration(1000);
				colorAnim.setEvaluator(new ArgbEvaluator());
				colorAnim.setRepeatCount(ValueAnimator.INFINITE);
				colorAnim.setRepeatMode(ValueAnimator.RESTART);
				colorAnim.start();
			}


		}


	}// end of public void setServerDetailsInUI(){

	/******************************************************************************************
	 * To receive an event
	 * @param event SyncATSCompletedRespEvent
	 * @version History:
	 *      @author Pushpalatha
	 *      @version V3.14.0 {@date} 25/09/2019
	 ******************************************************************************************/
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onEvent(SyncATSCompletedRespEvent event) {

		Log.d(TAG, "::onEvent > CALLED & Receiving event: SyncATSCompletedRespEvent");

		// Change and setup the server
		if (this.selectedChangedServerTypeDetails == null) {
			return;
		}

		Log.d(TAG, "::onEvent > CALLED & Receiving event: SyncCompleteResponseEvent");

		//while syncing any error received , reset selected server type as null
		if (event.isStatus() == false) {

			Toast.makeText(context, "Can't change to " +
							ServerType.getServerTypeString(
									ServerType.getServerType(
											this.selectedChangedServerTypeDetails.getServerType())) +
							" Server",
					Toast.LENGTH_LONG).show();


		} else {

			// check if selected server is different, then clear the database
			int alreadySelectedServerType = LoginServerDao.getCurrentServerType();

			// check if server type is changed then clear the database
			if (alreadySelectedServerType != ServerType.getServerType(selectedChangedServerTypeDetails.getServerType())) {

				// Cleanup android database
				clearDatabase();

				// remove details of login user also
				LoginUserDao.removeAll();


				// Update the record in the local database
				LoginServerDao.setUpServer(
						ServerType.getServerType(selectedChangedServerTypeDetails.getServerType()),
						ServerType.getServerIpString(
								ServerType.getServerType(selectedChangedServerTypeDetails.getServerType())));

				// Set up rest client
				TPMSApp.setUpRestClient();
			}


		}

		// show currently connected server to user
		setServerDetailsInUI();

		// reset the selected server as null
		this.selectedChangedServerTypeDetails = null;

	}// end of   public void onEvent(SyncATSCompletedRespEvent event) {


	/**
	 * To get email and send the Account activation link
	 *
	 * @version history:
	 * @author Pushpalatha
	 * @version CH-V1.0 {@date} 29/10/2019
	 */
	private void sendActivationLink() {

		// If no net connection, alert the user
		if (!NetworkUtils.checkNetworkConnection(context)) {

			Toast.makeText(context, "No net connection", Toast.LENGTH_LONG).show();
			return;
		}


		// Declare the builder here
		final AlertDialog.Builder emailDialog = new AlertDialog.Builder(this);

		// Set message
		emailDialog.setMessage("Send Activation Link:");

		// Set an EditText view to get user input
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		params.setMargins(20, 0, 30, 0);
		final EditText input = new EditText(this);
		layout.addView(input, params);
		emailDialog.setView(layout);

		// set "Cancel" button to close the dialog
		emailDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				dialogInterface.dismiss();
			}
		});


		// Set "Send reset link" button to send the link
		emailDialog.setPositiveButton("Send", null);

		final AlertDialog sendActivationLinkDialog = emailDialog.create();

		// show the alert dialog
		sendActivationLinkDialog.show();


		sendActivationLinkDialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(
				new OnClickListener() {
					@Override
					public void onClick(View view) {
						// email id of the user
						String email = input.getText().toString();


						// check for validation
						if (!Constants.isValidEmailMatches(email)) {
							Toast.makeText(context, "E-mail id is invalid. Can't send the activation link.",
									Toast.LENGTH_LONG).show();
							return;
						}

						try {
							// Show "Loading" message , which cannot be cancelable by the user
							loadingProgress = new ProgressDialog(context);
							loadingProgress.setMessage("Sending... Please wait");
							loadingProgress.setCancelable(false);
							loadingProgress.show();

							// send email id to the server
							AccountActivationReqEvent.send(email.trim());

						} catch (Exception e) {

							// Invalidate the progress dialog
							loadingProgress = null;
							e.printStackTrace();
						}

						// Close the alert dialog
						sendActivationLinkDialog.dismiss();
					}
				}
		);


	}


	/******************************************************************************************
	 * To receive an event
	 * @param event AccountActivationRespEvent
	 * @version History:
	 *      @author Pushpalatha
	 *      @version CH-V1.0 {@date} 29/10/2019
	 ******************************************************************************************/
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onEvent(AccountActivationRespEvent event) {

		Log.d(TAG, "::onEvent > CALLED & Receiving event: AccountActivationRespEvent");

		// Dismiss the progress dialog
		if (loadingProgress != null && loadingProgress.isShowing()) {
			loadingProgress.dismiss();
			loadingProgress = null;
		}

		// Check status of server response
		// If status is true, handle different login status
		// Otherwise show error message
		if (!event.isStatus()) {

			// Show error message in the alert dialog
			MessageAlertDialog.showErrorAlert(
					event.getMessage(),        // message
					this.context);               // context

		} else {

			// notify the user
			MessageAlertDialog.showAlertDialog("",
					event.getMessage(),
					this.context);

		}// end of else

		Log.d(TAG, "::onEvent > AccountActivationRespEvent method ENDED");

	}// end of   public void onEvent(AccountActivationRespEvent event) {


	/**
	 * Edited by Nikhil
	 * @date 14/05/2020
	 */
	private void selectLanguage() {
		List<LanguageViewDTO> mList = new ArrayList<>();
		String selectedLanguage = sharedPreferences.getString(SAVED_LOCALE,Language.getLanguage(Language.English.getValue()));
		mList.clear();
		mList.addAll(getLanguageList());
		LinearLayout mButtonLayout = new LinearLayout(this);
		mButtonLayout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams mParams = new LinearLayout.LayoutParams(260,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		mButtonLayout.setLayoutParams(mParams);
		mButtonLayout.removeAllViews();
		for (final LanguageViewDTO lang:
				mList) {
			View btn_View = View.inflate(this,R.layout.select_lang_layout_button,null);
			final Button langButton = (Button) btn_View.findViewById(R.id.btn_lang);
			langButton.setText(lang.getLanguageName());
			if (lang.getLanguageCode().equals(selectedLanguage))
				langButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
			else
				langButton.setBackgroundColor(getResources().getColor(R.color.colorLightDark));

			langButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(dialog != null) {
						dialog.dismiss();
					}
					changeLang(lang.getLanguageCode());
				}
			});

			mButtonLayout.addView(btn_View);
		}

		this.dialog = new Dialog(this);
		this.dialog.setContentView(mButtonLayout);

		Window dialogWindow = this.dialog.getWindow();
		WindowManager.LayoutParams lp = dialogWindow.getAttributes();
		dialogWindow.setGravity(Gravity.CENTER);
		dialogWindow.setAttributes(lp);
		this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		this.dialog.show();
	}


	/**
	 * Edited by Nikhil
	 * @date 14/05/2020
	 */
	private List<LanguageViewDTO> getLanguageList() {
		List<LanguageViewDTO> list = new ArrayList<>();
		list.add(new LanguageViewDTO("English","0","en"));
		list.add(new LanguageViewDTO("italiano","0","it"));
		list.add(new LanguageViewDTO("Française","0","fr"));
		list.add(new LanguageViewDTO("Española","0","es"));
		list.add(new LanguageViewDTO("Nederlands","0","nl"));
		list.add(new LanguageViewDTO("Deutsche","0","de"));
		list.add(new LanguageViewDTO("Polskie","0","pl"));
		return list;
	}

	public void changeLang(String lang) {
		if (lang.equalsIgnoreCase(""))
			return;
		myLocale = new Locale(lang);//Set Selected Locale
		saveLocale(lang);//Save the selected locale
		Locale.setDefault(myLocale);//set new locale as default
		Configuration config = new Configuration();//get Configuration
		config.locale = myLocale;//set config locale as selected locale
		getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());//Update the config
		updateTexts();//Update texts according to locale
	}


	//Save locale method in preferences
	public void saveLocale(String lang) {
		editor.putString(SAVED_LOCALE, lang);
		editor.commit();
	}

	//Get locale method in preferences
	public void loadLocale() {
		String language = sharedPreferences.getString(SAVED_LOCALE, Language.getLanguage(Language.English.getValue()));
		changeLang(language);
	}


	private void updateTexts() {
		transPopId.setText(R.string.trans);
		tvUsername.setText(R.string.userid);
		login.setText(R.string.login);
		tvPassword.setText(R.string.password);
		joinNow.setText(R.string.sign_up);
		btnLogin.setText(R.string.login);
		changeServerButton.setText(R.string.change);
		btnForgotPassword.setText(R.string.forgot_password);
		language_View.setText(R.string.btn_en);
	}


//	@Override
//	public void onConfigurationChanged(android.content.res.Configuration newConfig) {
//		super.onConfigurationChanged(newConfig);
//		if (myLocale != null){
//			newConfig.locale = myLocale;
//			Locale.setDefault(myLocale);
//			getBaseContext().getResources().updateConfiguration(newConfig, getBaseContext().getResources().getDisplayMetrics());
//		}
//	}

}// end of public class LoginActivity
