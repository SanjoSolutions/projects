module.exports = function() {
  return {
    devtool: 'eval-sourcemap',
  }; 
};